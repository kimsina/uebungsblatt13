package pauleistzurueck;

import de.unistuttgart.iste.rss.oo.hamstersimulator.datatypes.Direction;
import de.unistuttgart.iste.rss.oo.hamstersimulator.datatypes.Location;
import de.unistuttgart.iste.rss.oo.hamstersimulator.datatypes.Size;
import de.unistuttgart.iste.rss.oo.hamstersimulator.external.model.Hamster;
import de.unistuttgart.iste.rss.oo.hamstersimulator.external.model.HamsterGame;
import de.unistuttgart.iste.rss.oo.hamstersimulator.external.model.Territory;
import de.unistuttgart.iste.rss.oo.hamstersimulator.internal.model.territory.TerritoryBuilder;
import de.unistuttgart.iste.rss.oo.hamstersimulator.ui.javafx.JavaFXInputInterface;
import de.unistuttgart.iste.rss.oo.hamstersimulator.ui.javafx.JavaFXUI;

public class Baum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final HamsterGame hamsterGame = new HamsterGame();
		final TerritoryBuilder territoryBuilder = hamsterGame.getNewTerritoryBuilder();
		territoryBuilder.initializeTerritory(new Size(7,5));
		territoryBuilder.defaultHamsterAt(new Location(1,1), Direction.EAST, 55);
		territoryBuilder.grainAt(new Location(1,3));
		for(int i = 0; i<7; i++) {
			territoryBuilder.wallAt(new Location(0,i));
			territoryBuilder.wallAt(new Location(4,i));
		}
		for(int i = 0; i<5; i++) {
			territoryBuilder.wallAt(new Location(i,0));
			territoryBuilder.wallAt(new Location(i,6));
		}
		hamsterGame.initialize(territoryBuilder);
		JavaFXUI.start();
		JavaFXInputInterface myInterface = new JavaFXInputInterface();
		hamsterGame.displayInNewGameWindow();
		hamsterGame.startGame(false);
		runHamster(hamsterGame.getTerritory());
		hamsterGame.stopGame();
	}

	static private void runHamster(Territory territory) {
		Hamster paule = territory.getDefaultHamster();
		paule.move();
		paule.move();
		paule.pickGrain();
		
	}
}
