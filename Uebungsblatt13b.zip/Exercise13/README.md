# exercise-sheet-13

This repository contains the files needed to get started with exercise sheet 13. Please import the projects in a running Eclipse instance using the EGit plugin. 

An introduction how to import a Git Repository into Eclipse is available for example at https://www.youtube.com/watch?v=38JFCqi_X3c
